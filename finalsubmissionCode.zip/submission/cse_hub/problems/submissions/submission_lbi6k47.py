x = int(input())
print(x**2)